import random

kwota = int(input("ile pieniędzy wpłacasz?"))
wybor = int(input("na co stawiasz 1 - czarne, 2 - czerwone, 3 - zielone, 1-36 - numer "))

liczba = random.randint(0,37)
czarne = [2, 4, 6, 8, 10, 11, 13, 15, 17, 20, 22, 24, 26, 28, 29, 31, 33, 35]
czerwone = [1, 2, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36]
zielone = [0, 37]



if liczba == [2, 4, 6, 8, 10, 11, 13, 15, 17, 20, 22, 24, 26, 28, 29, 31, 33, 35]:
    print("czarne")

    if wybor == "1":

        print("Wygrałeś")
    else:
        print("Przegrałeś :(")

elif liczba == [1, 2, 5, 7, 9, 12, 14, 16, 18, 19, 21, 23, 25, 27, 30, 32, 34, 36]:
    print("czerwone")

    if wybor == "2":

        print("Wygrałeś")
    else:
        print("Przegrałeś :(")

else:
    print("zielone")

    if wybor == "3":
        
        print("Wygrałeś")
    else:
        print("Przegrałeś :(")

