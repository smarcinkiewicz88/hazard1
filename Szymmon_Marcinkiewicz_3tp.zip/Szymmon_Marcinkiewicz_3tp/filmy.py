a = int(input("podaj wiek"))

if a >= 18:
    print("możesz oglądać filmy dla dorosłych :)")
else:
    print("nie możesz oglądać filmów dla dorosłych :(")